import junit.framework.TestCase;


public class NumberGuessTest extends TestCase {

}
